const DB = wx.cloud.database().collection("temp")
var app = getApp()
let temp = ''
var wendu = new Array()
var average = 0
var lower = 0
var upper = 0
var conf = 0

Page({
  data: {
    connectedDeviceId: "", //已连接设备uuid
    services: "", // 连接设备的服务
    characteristics: "",   // 连接设备的状态值
    writeServicweId: "", // 可写服务uuid
    writeCharacteristicsId: "",//可写特征值uuid
    readServicweId: "", // 可读服务uuid
    readCharacteristicsId: "",//可读特征值uuid
    notifyServicweId: "", //通知服务UUid
    ALLUUID: "9FA480E0-4967-4542-9390-D343DC5D04AE",//同时具有可读、可写、通知三种属性的UUID
    sendmsg: "",
    yi:"block",
    er:"block",
    winWidth: 0,
    winHeight: 0,
    // tab切换
    currentTab: 0,
  },

  onLoad: function () {
    var that = this
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          clientHeight: res.windowHeight -  40
                });
      }
    })
  },
  /**
     * 滑动切换tab
     */
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /**
   * 点击tab切换
   */
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },

  // 初始化蓝牙适配器
  lanya1: function () {
    var that = this;
    wx.openBluetoothAdapter({
      success: function (res) {
        console.log('初始化蓝牙适配器返回' + JSON.stringify(res))
        //页面日志显示
        that.setData({
          msg: JSON.stringify(res)
        })
      },
      fail: function (res) {
        console.log('初始化蓝牙适配器失败' + JSON.stringify(res))
      }
    })
  },

  // 本机蓝牙适配器状态
  lanya2: function () {
    var that = this;
    wx.getBluetoothAdapterState({
      success: function (res) {
        //页面日志显示
        that.setData({
          msg: "本机蓝牙适配器状态" + "/" + JSON.stringify(res.errMsg) + "==是否可用：" + res.available


        })

      },
      fail: function (res) {
        //页面日志显示
        that.setData({
          msg: "本机蓝牙适配器状态" + "/" + JSON.stringify(res.errMsg) + "==是否可用：" + res.available

        })

      }
    })
  },

  //搜索设备
  lanya3: function () {
    var that = this;
    wx.startBluetoothDevicesDiscovery({
      //services: ['FEE7'],
      success: function (res) {
        that.setData({
          msg: "搜索设备" + JSON.stringify(res),
        })
        console.log('搜索设备返回' + JSON.stringify(res))

      },
      fail:function(res)
      {
        console.log('调用失败')
      }
    })
  },

  // 获取所有已发现的设备
  lanya4: function () {
    var that = this;
    wx.getBluetoothDevices({
      success: function (res) {

        that.setData({
          msg: "搜索设备" + JSON.stringify(res.devices),
          devices: res.devices
        })
        console.log('搜到的蓝牙设备数目：' + res.devices.length)
        console.log('获取到周边搜到的设备信息：' + JSON.stringify(res.devices))
      },
      fail: function (res) {
        console.log('调用失败')
      }
      
    })
  },

  //连接设备
  connectTO: function (e) {
    var that = this;
    wx.createBLEConnection({
      deviceId: "6D:B4:27:80:1D:D8",
      success: function (res) {
        console.log('连接设备返回：' + res.errMsg);
        that.setData({
          connectedDeviceId: "6D:B4:27:80:1D:D8",
          msg: "已连接" + "6D:B4:27:80:1D:D8" + '===' + '连接设备返回：' + res.errMsg,
          msg1: "",
        })
      },
      fail: function () {
        console.log("调用失败");
      },
      complete: function () {
        console.log("调用结束");
      }

    })
    console.log(that.data.connectedDeviceId);
  },

  //停止搜索周边设备
  lanya5: function () {
    var that = this;
    wx.stopBluetoothDevicesDiscovery({
      success: function (res) {
        that.setData({
          msg: "停止搜索周边设备" + "/" + JSON.stringify(res.errMsg),
          sousuo: res.discovering ? "在搜索。" : "未搜索。",
          status: res.available ? "可用。" : "不可用。",
        })
      }
    })
  },

  // 获取连接设备的service服务
  lanya6: function () {
    var that = this;
    wx.getBLEDeviceServices({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      success: function (res) {
        console.log('device services:', JSON.stringify(res.services));
        for (var i = 0; i < res.services.length; i++) {
          console.log(i + "--UUID:------" + res.services[i].uuid)
          //var servicesUuid = res.services[i].uuid

        }
        that.setData({
          services: res.services,
          msg: JSON.stringify(res.services),
        })
      }
    })
  },

  //获取连接设备的所有特征值
  lanya7: function () {
    var that = this;
    var myuuid = that.data.ALLUUID//具有读、写、通知、属性的服务uuid
    console.log('myuuid' + myuuid)
    wx.getBLEDeviceCharacteristics({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: myuuid,
      success: function (res) {
        for (var i = 0; i < res.characteristics.length; i++) {
          console.log('特征值：' + res.characteristics[i].uuid)

          if (res.characteristics[i].properties.notify) {
            console.log("获取开启notify的ServicweId：", myuuid);
            console.log("获取开启notify的CharacteristicsId：", res.characteristics[i].uuid);
            that.setData({
              notifyServicweId: myuuid,
              notifyCharacteristicsId: res.characteristics[i].uuid,

            })
          }
          if (res.characteristics[i].properties.write) {
            console.log("获取开启write的ServicweId：", myuuid);
            console.log("获取开启write的CharacteristicsId：", res.characteristics[i].uuid);
            that.setData({
              writeServicweId: myuuid,
              writeCharacteristicsId: res.characteristics[i].uuid,
            })

          } else if (res.characteristics[i].properties.read) {
            console.log("读read操作readServicweId：", myuuid);
            console.log("读read操作：readCharacteristicsId", res.characteristics[i].uuid);
            that.setData({
              readServicweId: myuuid,
              readCharacteristicsId: res.characteristics[i].uuid,
            })

          }

        }
        console.log('device getBLEDeviceCharacteristics:', res.characteristics);

        that.setData({
          msg: JSON.stringify(res.characteristics),
        })
      },
      fail: function () {
        console.log("fail");
      },
      complete: function () {
        console.log("complete");
      }
    })


  },

  //启用低功耗蓝牙设备特征值变化时的 notify 功能  
  lanya8: function () {
    var that = this;
    var notifyServicweId = that.data.ALLUUID  //具有读、写、通知、属性的服务uuid
    var notifyCharacteristicsId = that.data.notifyCharacteristicsId;
    console.log("启用notify的serviceId", notifyServicweId);
    console.log("启用notify的notifyCharacteristicsId", notifyCharacteristicsId);

    wx.notifyBLECharacteristicValueChange({
      state: true, // 启用 notify 功能
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: notifyServicweId,

      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.notifyCharacteristicsId,

      success: function (res) {
        console.log('notifyBLECharacteristicValueChange success', res.errMsg)
        var msg = '启动通知notify返回:' + res.errMsg
        that.setData({
          msg: msg
        })
      },
      fail: function () {
        console.log('shibai0');
        console.log(that.data.notifyServicweId);
        console.log(that.data.notifyCharacteristicsId);
      },
    })



  },

  //向蓝牙设备发送16进制数据
  lanya10: function () {
    var that = this
    console.log('开始发送指令------------')
    var hex = that.data.sendmsg
    // 向蓝牙设备发送16进制数据
    var typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function (h) {
      return parseInt(h, 16)
    }))
    console.log(typedArray)
    var buffer1 = typedArray.buffer
    wx.writeBLECharacteristicValue({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: that.data.ALLUUID,
      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.writeCharacteristicsId,
      // 这里的value是ArrayBuffer类型
      value: buffer1,
      success: function (res) {
        console.log('向蓝牙设备写入返回：writeBLECharacteristicValue success', res.errMsg)
      }
    })
  },

  //获取输入框的数据
  getmsg(event) {
    this.setData({
      sendmsg: event.detail.value
    })

  },

  //接收消息
  lanya9: function () {
    var that = this;
    console.log("调用接收消息函数----");
    wx.onBLECharacteristicValueChange(function (res) {
      console.log("接收函数返回值：" + res)
      console.log("接收函数返回值characteristicId：" + res.characteristicId)
      console.log("接收函数返回的serviceId:" + res.serviceId)
      console.log("deviceId" + res.deviceId)
      console.log("长度:" + res.value.byteLength)
      console.log("jieshoudao:" + ab2hex(res.value))
      that.setData({
        jieshou: res.value,
        msg: res.value
      })

    })
  },

  //断开设备连接
  lanya0: function () {
    var that = this;
    wx.closeBLEConnection({
      deviceId: that.data.connectedDeviceId,
      success: function (res) {
        that.setData({
          connectedDeviceId: "",
        })
        console.log('断开蓝牙设备连接返回：' + res.errMsg)
      }
    })
  },


  one: function () {
    var that = this
    console.log('开始发送指令------------')
    var hex = '01'
    // 向蓝牙设备发送16进制数据
    var typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function (h) {
      return parseInt(h, 16)
    }))
    console.log(typedArray)
    var buffer1 = typedArray.buffer
    wx.writeBLECharacteristicValue({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: that.data.ALLUUID,
      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.writeCharacteristicsId,
      // 这里的value是ArrayBuffer类型
      value: buffer1,
      success: function (res) {
        console.log('向蓝牙设备写入返回：writeBLECharacteristicValue success', res.errMsg)
      }
    })
  },

  two: function () {
    var that = this
    console.log('开始发送指令------------')
    var hex = '04'
    // 向蓝牙设备发送16进制数据
    var typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function (h) {
      return parseInt(h, 16)
    }))
    console.log(typedArray)
    var buffer1 = typedArray.buffer
    wx.writeBLECharacteristicValue({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: that.data.ALLUUID,
      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.writeCharacteristicsId,
      // 这里的value是ArrayBuffer类型
      value: buffer1,
      success: function (res) {
        console.log('向蓝牙设备写入返回：writeBLECharacteristicValue success', res.errMsg)
      }
    })
  },

  next: function () {
    var that = this
    console.log('开始发送指令------------')
    var hex = '01'
    // 向蓝牙设备发送16进制数据
    var typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function (h) {
      return parseInt(h, 16)
    }))
    console.log(typedArray)
    var buffer1 = typedArray.buffer
    wx.writeBLECharacteristicValue({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: that.data.ALLUUID,
      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.writeCharacteristicsId,
      // 这里的value是ArrayBuffer类型
      value: buffer1,
      success: function (res) {
        console.log('向蓝牙设备写入返回：writeBLECharacteristicValue success', res.errMsg)
      }
    })
  },

  add: function () {
    var that = this
    console.log('开始发送指令------------')
    var hex = '02'
    // 向蓝牙设备发送16进制数据
    var typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function (h) {
      return parseInt(h, 16)
    }))
    console.log(typedArray)
    var buffer1 = typedArray.buffer
    wx.writeBLECharacteristicValue({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: that.data.ALLUUID,
      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.writeCharacteristicsId,
      // 这里的value是ArrayBuffer类型
      value: buffer1,
      success: function (res) {
        console.log('向蓝牙设备写入返回：writeBLECharacteristicValue success', res.errMsg)
      }
    })
  },

  subtract: function () {
    var that = this
    console.log('开始发送指令------------')
    var hex = '03'
    // 向蓝牙设备发送16进制数据
    var typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function (h) {
      return parseInt(h, 16)
    }))
    console.log(typedArray)
    var buffer1 = typedArray.buffer
    wx.writeBLECharacteristicValue({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: that.data.ALLUUID,
      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.writeCharacteristicsId,
      // 这里的value是ArrayBuffer类型
      value: buffer1,
      success: function (res) {
        console.log('向蓝牙设备写入返回：writeBLECharacteristicValue success', res.errMsg)
      }
    })
  },

  //获取温度
  gettemp: function(){
    var that = this
    console.log('开始发送指令------------')
    var hex = '06'
    // 向蓝牙设备发送指令
    var typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function (h) {
      return parseInt(h, 16)
    }))
    console.log(typedArray)
    var buffer1 = typedArray.buffer
    wx.writeBLECharacteristicValue({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: that.data.ALLUUID,
      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.writeCharacteristicsId,
      // 这里的value是ArrayBuffer类型
      value: buffer1,
      success: function (res) {
        console.log('向蓝牙设备写入返回：writeBLECharacteristicValue success', res.errMsg)
      }
    })
    //接收数据
    console.log("调用接收消息函数----");
    wx.onBLECharacteristicValueChange(function (res) {
      console.log("接收函数返回值：" + res)
      console.log("接收函数返回值characteristicId：" + res.characteristicId)
      console.log("接收函数返回的serviceId:" + res.serviceId)
      console.log("deviceId" + res.deviceId)
      console.log("长度:" + res.value.byteLength)
      console.log("jieshoudao:" + ab2hex(res.value))
      that.setData({
        temp: res.value,
        msg: res.value
      })
    })
  }
,
  addData(){
    DB.add({
      data:{
        wendu:temp
      },
      success(res){
        console.log('添加成功',res)
      },
      fail(res){
        console.log('添加失败', res)
      }
    })
  },

  //从云数据库获取一组数据
  getfromdb: function () {
    var _this = this;
    const db = wx.cloud.database({
      env: 'ame-gc0t3'
    })
    db.collection('temp').get({

      success: res => {
        console.log(res.data)
        this.setData({
          wendu: res.data
        })
      }
    })
  },

  //计算均值
  avg: function () {
    let sum = 0;
    for (let i = 0; i < wendu.length; i++) {
      sum += wendu[i];
    }
    average = sum / wendu.length;
  },

  //计算置信区间
  conf: function () {
    var t, s;
    var m = 0;
    var table = new Array(12.7032, 4.3027, 3.1824, 2.7764, 2.5706, 2.4469, 2.3646, 2.3060);
    t = table[wendu.length - 1];
    for (let i = 0, temp = 0; i < wendu.length; i++) {
      m += (wendu[i] - average) * (wendu[i] - average);
    }
    s = m / (wendu.length - 1);
    lower = average - t * s / Math.sqrt(wendu.length);
    upper = average + t * s / Math.sqrt(wendu.length);
  }
})

// ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  var hexArr = Array.prototype.map.call(
    new Uint8Array(buffer),
    function (bit) {
      return ('00' + bit.toString(16)).slice(-2)
    }
  )
  return hexArr.join('');
}